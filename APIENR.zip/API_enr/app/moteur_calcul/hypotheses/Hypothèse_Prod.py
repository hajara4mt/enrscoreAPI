ZONES = {
    "Z1": 1048,
    "Z2": 1091,
    "Z3": 1096,
    "Z4": 1161,
    "Z5": 1190,
    "Z6": 1210,
    "Z7": 1283,
    "Zcorse": 1496,
    "Zguadeloupe": 1579,
    "Zguyane": 1500,
    "Zréunion": 1489,
    "Zmartinique": 1278,
    "Zmayotte": 1226
}