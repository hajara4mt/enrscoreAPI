mapping = {
    ("Bureaux", "Electrique"): "bureaux_elec",
    ("Bureaux", "Autre"): "bureaux_autre",
    ("Commerce", "Electrique"): "commerce_elec",
    ("Commerce", "Autre"): "commerce_autres",
    ("Logistique", "Electrique"): "logistique_elec",
    ("Logistique", "Autre"): "logistique_autres",
    ("Résidentiel", "Electrique"): "residentiel_elec",
    ("Résidentiel", "Autre"): "residentiel_autres"
}