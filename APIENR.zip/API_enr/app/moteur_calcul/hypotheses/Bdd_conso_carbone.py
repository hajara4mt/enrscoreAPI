Baisse_conso_besoins = {
    "Aucune (Bâtiment existant)" : 0,
    "Aucune (Bâtiment neuf)" :0,
    "Rénovation légère (Quick Win)":  0.25 ,
    "Rénovation d'ampleur (grand saut)" : 0.5
    }

