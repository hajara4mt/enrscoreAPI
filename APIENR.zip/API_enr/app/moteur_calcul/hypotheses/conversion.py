conversion = {
    "Electricité": 1.0,
    "Gaz naturel": 1.11,
    "Gaz butane/propane": 1.087,
    "Fioul": 1.075,
    "Charbon": 1.052,
    "Bois plaquettes": 1.11,
    "Bois granulés": 1.11,
    "Réseau de chaleur": 1.0,
    "Réseau de froid": 1.0
}