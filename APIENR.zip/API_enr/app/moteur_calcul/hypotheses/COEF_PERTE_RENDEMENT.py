COEF_PERTE_RENDEMENT= {
    "Bâtiment à moins de L=H": 0.65,
    "Végétation dense et haute": 0.75,
    "Végétation peu impactante": 0.90,
    "Aucun": 0.95
}